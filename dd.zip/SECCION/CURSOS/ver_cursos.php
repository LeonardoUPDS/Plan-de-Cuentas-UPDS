<?php
// ahora la lista de cursos está en index.php
header('Location: index.php');
exit;
?>
